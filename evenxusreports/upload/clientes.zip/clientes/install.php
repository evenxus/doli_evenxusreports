<?php
/* Copyright (C) 2013-     Santiago Garcia      <babelsistemas@gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

$NombreReporte=  "clientes";

$NombreJasper =   $NombreReporte.".jasper";
$NombreFiltros=   $NombreReporte.".php";
$NombreIdioma =   $NombreReporte.".lang";

// Movemos idiomas
rename("../upload/".$NombreReporte."/langs/es_ES/".$NombreIdioma,"../langs/es_ES/".$NombreIdioma); // Español
// Cargamos idiomas del reporte
$langs->load("clientes@evenxusreports");

// Movemos jasper
print $langs->trans("InstalandoFicheroReporte")."<br>"; 
rename("../upload/".$NombreReporte."/".$NombreJasper,"../reports/".$NombreJasper);

// Movemos pantalla de filtros
print $langs->trans("InstalandoFiltrosReporte")."<br>"; 
rename("../upload/".$NombreReporte."/".$NombreFiltros,"../frontend/".$NombreFiltros);

// Creamos entradas de Menu
print $langs->trans("CreandoMenus")."<br>"; 
// Padre (Menu de grupo) por eso el -1
CrearMenu($NombreReporte,7701000,-1,"100001","clientes.php","Terceros",""); 
// Entrada menu
CrearMenu($NombreReporte,7701001,7701000,"100002",$NombreFiltros,"Clientes",$NombreReporte);

// Creamos entrada de reporte en base de datos
print $langs->trans("CreandoReporte")."<br>"; 
AddReporte(7701001, "Clientes","ListadoClientes","/frontend/clientes.php,
												  /reports/clientes.jasper",1);
// Creamos enlace de seguridad
print $langs->trans("CreandoPermisosReporte")."<br>"; 
AddPermiso(7701001,"PermitirUsarListadoClientes",$NombreReporte);

